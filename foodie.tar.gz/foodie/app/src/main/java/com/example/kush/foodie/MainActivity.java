package com.example.kush.foodie;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Locale;

import clarifai2.api.ClarifaiBuilder;
import clarifai2.api.ClarifaiClient;
import clarifai2.api.ClarifaiResponse;
import clarifai2.dto.input.ClarifaiInput;
import clarifai2.dto.input.image.ClarifaiImage;
import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity {

    //public Uri imageUrl;
    //ProgressDialog progress;
    //public String predictions;
    //EditText result;
//    class test extends AsyncTask<Void, Void, Void>{
//
//        @Override
//        protected void onPreExecute() {
//            Toast.makeText(MainActivity.this, " trying to find out the item ", Toast.LENGTH_SHORT).show();
//            predictions = " ";
//            super.onPreExecute();
//        }
//
//        /**
//         * Override this method to perform a computation on a background thread. The
//         * specified parameters are the parameters passed to {@link #execute}
//         * by the caller of this task.
//         * <p>
//         * This method can call {@link #publishProgress} to publish updates
//         * on the UI thread.
//         *
//         * @param params The parameters of the task.
//         * @return A result, defined by the subclass of this task.
//         * @see #onPreExecute()
//         * @see #onPostExecute
//         * @see #publishProgress
//         */
//
//
//
//        @Override
//        protected Void doInBackground(Void... params) {
//            ClarifaiClient clarifai = new ClarifaiBuilder("UWR9Tctjv-sSlgx_gG0-3wfZZpRFN5lYWYk15yUi", "A6s1uzBvH-lvcBmBuMsznoZmNvTr1LzSHoq_sOp0")
//                    .client(new OkHttpClient()) // OPTIONAL. Allows customization of OkHttp by the user
//                    .buildSync();// or use .build() to get a Future<ClarifaiClient>
//
//            // if a Client is registered as a default instance, it will be used
//            // automatically, without the user having to keep it around as a field.
//            // This can be omitted if you want to manually manage your instance
//            //.registerAsDefaultInstance();
//
//            ClarifaiResponse response = clarifai.getDefaultModels().foodModel().predict()
//                    .withInputs(
//                            ClarifaiInput.forImage(ClarifaiImage.of(imageUrl.toString()))
//                    )
//                    .executeSync();
//            progress.setProgress(75);
//            JSONObject responseJSON = null;
//            System.out.println(response.rawBody());
//            System.out.println(response.rawBody());
//            System.out.println(response.rawBody());
//            System.out.println(response.rawBody());
//            try {
//                responseJSON= new JSONObject(response.rawBody());
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            JSONObject output=null;
//            JSONArray data=null;
//            try {
//                output = responseJSON.getJSONArray("outputs").getJSONObject(0);
//                data = output.getJSONObject("data").getJSONArray("concepts");
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            try{
//                progress.setProgress(90);
//                for(int i=0;i<data.length();i++){
//                    JSONObject obj = data.getJSONObject(i);
//                    System.out.println(obj.getString("name")+obj.getString("value"));
//                    if( Float.valueOf(obj.getString("value")) > 0.95 ) {
//                        predictions =predictions+ obj.getString("name")+ " " + obj.getString("value") + "\n";
//                    }
//                }
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//            System.out.print("test");
//            System.out.print("");
//            progress.setProgress(100);
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(Void aVoid) {
//            progress.dismiss();
//            Toast.makeText(MainActivity.this, "result in logs", Toast.LENGTH_SHORT).show();
//            result.setText(predictions);
//            result.setAlpha(1);
//            super.onPostExecute(aVoid);
//
//        }
//    }



//    private static final int CAMERA_REQUEST = 1888;


    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView)this.findViewById(R.id.iv);
    //    videoView = (VideoView)findViewById(R.id.videoView);
//        Button videoButton =(Button)findViewById(R.id.b4);
    //    progress = new ProgressDialog(this);
      //  result = (EditText)findViewById(R.id.editText);
        Button photoButton = (Button)findViewById(R.id.b3);
        photoButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
//                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivityForResult(cameraIntent, CAMERA_REQUEST);

                Intent myIntent = new Intent(MainActivity.this,ClickingActivity.class);
                startActivity(myIntent);
            }
        });

    }


//    public void imageupload ( Intent data){
//
//        Bitmap bitmap = (Bitmap) data.getExtras().get("data");
//        ByteArrayOutputStream bitOut = new ByteArrayOutputStream();
//        bitmap.compress(Bitmap.CompressFormat.JPEG,100 , bitOut);
//        byte[] dataBAOS = bitOut.toByteArray();
//
//
//        progress.setMessage(" finding data ... ");
//        progress.setIndeterminate(true);
//        progress.show();
//
//        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
//        StorageReference imagesRef = storageRef.child("photo");
//        UploadTask uploadTask = imagesRef.putBytes(dataBAOS);
//        uploadTask.addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(getApplicationContext(), "Sending failed", Toast.LENGTH_SHORT).show();
//
//            }
//        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//            @Override
//            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//                imageUrl = taskSnapshot.getDownloadUrl();
//                Log.e("uri :-",""+imageUrl);
//                progress.setProgress(50);
//                imageView.setVisibility(View.VISIBLE);
//                new test().execute();
//
//            }
//        });
//
//
//
//    }
//
//
//
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
//            Bitmap photo = (Bitmap) data.getExtras().get("data");
//            imageView.setImageBitmap(photo);
//            imageupload(data);
//        }
//    }

}
